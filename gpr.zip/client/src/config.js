// export const BASE_URL = "http://localhost:8080/api/v1";
export const BASE_URL = "http://13.200.225.131:8080/api/v1";
