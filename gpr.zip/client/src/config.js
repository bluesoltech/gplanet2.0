export const BASE_URL = "http://43.205.65.72:8080/api/v1";
