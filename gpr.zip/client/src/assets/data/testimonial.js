export const testimonial = [
  {
    id: 1,
    name: "Amardeep Singh",
    img_url:
      "https://lh3.googleusercontent.com/a/AEdFTp7IiNkmgTDlb2aNYRFm0_GvB9xRj2ZcxshwXjb_Aw=s96-c?sz=200",
    rate: 5,
    msg: "It was very good event.",
  },
  {
    id: 2,
    name: "Beena Patel",
    img_url:
      "https://lh3.googleusercontent.com/a/ALm5wu1Z8soXTO5OtXEifJWQQRwwUxB9CuxcYW3NccgvfA=s96-c?sz=200",
    rate: 5,
    msg: "Good experience.",
  },
  {
    id: 3,
    name: "Yogesh Patel",
    img_url:
      "https://lh3.googleusercontent.com/a-/AAuE7mC6t-jSk8FQUtXTq1zdb4jFmufT1A-j968y-_Gpmg?sz=200",
    rate: 5,
    msg: "Very good arrangement we will wait next programmge...Yogesh Patel",
  },
  {
    id: 4,
    name: "Rasik Kumbhani",
    img_url:
      "https://www.gravatar.com/avatar/a84cca1ee4b9c21f4003e038f5e4fe6c?s=800&d=identicon&r=g",
    rate: 5,
    msg: "Good I am satisfied",
  },
  {
    id: 5,
    name: "Prasad Krishnan",
    img_url:
      "https://www.gravatar.com/avatar/d006b4a65d6c28c210f324a482f34e4b?s=800&d=identicon&r=g",
    rate: 5,
    msg: "Very well managed. Nice experience. Will return again next year",
  },
  {
    id: 6,
    name: "Namra Bhavsar",
    img_url:
      "https://www.gravatar.com/avatar/f3e27d728360d412d02c34a3e120d103?s=800&d=identicon&r=g",
    rate: 5,
    msg: "It was awesome, everyone just had so much of energy ⚡that the atmosphere was all motivating✌️",
  },
  {
    id: 7,
    name: "PREET PATEL",
    img_url:
      "https://www.gravatar.com/avatar/dd3ec275323ed98c0ec80b3198ce6380?s=800&d=identicon&r=g",
    rate: 5,
    msg: "It was the best experience of my life. ",
  },
];
