export const discounts = [
  {
    id: 1,
    code: "EARLYBIRD",
    type: "value",
    value: 50,
  },
  {
    id: 2,
    code: "GOGREENPLANET",
    type: "percent",
    value: 0.1,
  },
];
