export const about = [
  {
    title: "Green Planet Run",
    desc: "The run is about celebrating the passion of environmental sustainability and improvising reusable economy. This run is also for health awareness & advocating appropriate handling of e-waste as it impacts our health due to hazardous gasses & particles. Going in, you have to remember that the race is supposed to be the fun part... On The Occasion of National sports Day our prime minister Shri Narendra Modi ji launched the much-anticipated nation-wide ‘Fit India Movement’. This race urged citizens to make fitness a daily habit. The aim of GREEN PLANET RUN is to encourage people to prioritize fitness in their routine Lives.",
  },
];
