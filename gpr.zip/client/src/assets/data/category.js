export const category = [{ name: "5KM" }, { name: "10KM" }];
