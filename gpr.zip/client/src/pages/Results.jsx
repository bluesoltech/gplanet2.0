import React from "react";
import Dropdown1 from "../components/Result/Dropdown1";

const Results = () => {
  return (
    <div className="hero_section xl:h-[500px] flex items-center justify-center text-3xl text-textColor">
      <Dropdown1/>
    </div>
  );
};

export default Results;
